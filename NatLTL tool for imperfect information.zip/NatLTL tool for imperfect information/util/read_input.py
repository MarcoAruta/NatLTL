import numpy as np

graph = []
states = []
atomic_propositions = []
matrix_prop = []
initial_state = ''
number_of_agents = ''


# The function is used to read the content of the input file representing the model.
# It is designed in such a way that it can recognize the different parts of the text based
# on their title and appropriately divide it into sections.
# The different elements are then inserted into appropriate data structures.
def read_file(filename):
    global graph, states, atomic_propositions, matrix_prop, initial_state, number_of_agents

    with open(filename, 'r') as f:
        lines = f.readlines()

    # reset
    graph = []
    states = []
    atomic_propositions = []
    matrix_prop = []
    initial_state = ''
    number_of_agents = ''

    current_section = None
    transition_content = ''
    unknown_transition_content = ''
    name_state_content = ''
    atomic_propositions_content = ''
    labelling_content = ''
    rows_graph = []
    rows_prop = []

    for line in lines:
        line = line.strip()
        if line == 'Transition':
            current_section = 'Transition'
        elif line == 'Unkown_Transition_by':
            current_section = 'Unknown_Transition_by'
        elif line == 'Name_State':
            current_section = 'Name_State'
        elif line == 'Initial_State':
            current_section = 'Initial_State'
        elif line == 'Atomic_propositions':
            current_section = 'Atomic_propositions'
        elif line == 'Labelling':
            current_section = 'Labelling'
        elif line == 'Number_of_agents':
            current_section = 'Number_of_agents'
        elif current_section == 'Transition':
            transition_content += line + '\n'
            values = line.strip().split()
            rows_graph.append(values)
        elif current_section == 'Unknown_Transition_by':
            unknown_transition_content += line + '\n'
        elif current_section == 'Name_State':
            name_state_content += line + '\n'
            values = line.strip().split()
            states = np.array(values)
        elif current_section == 'Initial_State':
            initial_state = line
        elif current_section == 'Atomic_propositions':
            atomic_propositions_content += line + '\n'
            values = line.strip().split()
            atomic_propositions = np.array(values)
        elif current_section == 'Labelling':
            labelling_content += line + '\n'
            values = line.strip().split()
            rows_prop.append(values)
        elif current_section == 'Number_of_agents':
            number_of_agents = line

    grafo_prov = np.array(rows_graph)
    for row in grafo_prov:
        new_row = []
        for item in row:
            if item == '0':
                new_row.append(0)
            else:
                new_row.append(str(item))
        graph.append(new_row)

    # row = state, column = atom
    matrix_prop_prov = np.array(rows_prop)
    for row in matrix_prop_prov:
        new_row = []
        for item in row:
            if item == '0':
                new_row.append(0)
            elif item == '1':
                new_row.append(1)
            else:
                new_row.append(str(item))
        matrix_prop.append(new_row)


# It represents the model.
# Transitions are indicated through the actions performed by the agents from the source state (row) to the destination state (column).
def get_graph():
    return graph

# It returns the name of the states.
def get_states():
    return states

# returns the name of the atomic propositions
def get_atomic_prop():
    return atomic_propositions

# It returns a matrix that represents the atom labeling function.
# The rows represent the states, and the columns represent the atoms.
# The matrix indicates the values (between 0 and 1) of the atoms in each state.
def get_matrix_proposition():
    return matrix_prop


# returns the initial state
def get_initial_state():
    return initial_state


# returns the number of agents
def get_number_of_agents():
    return int(number_of_agents)

def get_actions(graph, agents):
    # Convert the graph string to a list of lists
    graph_list = graph

    # Create a dictionary to store actions for each agent
    actions_per_agent = {f"agent{agent}": [] for agent in agents}

    for row in graph_list:
        for elem in row:
            if elem != 0 and elem != '*':
                actions = elem.split(',')
                for action in actions:
                    for i, agent in enumerate(agents):
                        if action[agent - 1] != 'I':  # idle condition
                            actions_per_agent[f"agent{agent}"].append(action[agent - 1])

    # Remove duplicates from each agent's action list
    for agent_key in actions_per_agent:
        actions_per_agent[agent_key] = list(set(actions_per_agent[agent_key]))

    return actions_per_agent

#return the number of actions extracted in get_actions()
def get_number_of_actions ():

    n = get_actions()
    return len(n)

def write_updated_file(input_filename, modified_graph, output_filename):
    if modified_graph is None:
        raise ValueError("modified_graph is None")
    with open(input_filename, 'r') as input_file, open(output_filename, 'w') as output_file:
        current_section = None
        matrix_row = 0
        for line in input_file:
            line = line.strip()

            if line == 'Transition':
                current_section = 'Transition'
                output_file.write(line + '\n')
            elif current_section == 'Transition' and matrix_row < len(modified_graph):
                output_file.write(' '.join([str(elem) for elem in modified_graph[matrix_row]]) + '\n')
                matrix_row += 1
            elif current_section == 'Transition' and matrix_row == len(modified_graph):
                current_section = None
                output_file.write('Unkown_Transition_by' + '\n')
            else:
                output_file.write(line + '\n')

#returns the edges of a graph
def get_edges():
    graph = get_graph()
    states = get_states()
    #duplicate edges (double transactions from "a" to "b") are ignored due to model checking
    edges = []
    for i, row in enumerate(graph):
        for j, element in enumerate(row):
            if element == '*':
                edges.append((states[i], states[i]))
            elif element != 0:
                edges.append((states[i], states[j]))
    return edges

def file_to_string(filename):
    with open(filename, 'r') as file:
        data = file.read()
    return data