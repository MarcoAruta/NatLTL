import multiprocessing
import time
from src.strategies import initialize, generate_guarded_action_pairs, generate_strategies
from src.pruning import pruning

model = 'C:\\Users\\utente\\Desktop\\Lavoro\\LTL\\Memoryless\\Testing\\singleAgent.txt'
result = 'C:\\Users\\utente\\Desktop\\Lavoro\\LTL\\Memoryless\\Testing\\result.txt'
formulaLTL = 'C:\\Users\\utente\\Desktop\\Lavoro\\LTL\\Memoryless\\Testing\\formulaLTL.txt'



def sureWin(model, formula, result):
    start_time = time.time()
    found_solution = False
    k, agent_actions, actions_list, atomic_propositions, CTLformula, agents, cgs = initialize(model, formula)
    i = 1
    while not found_solution and i <= k:
        cartesian_products = generate_guarded_action_pairs(i, agent_actions, actions_list, atomic_propositions)
        strategies_generator = generate_strategies(cartesian_products, i, agents, found_solution)
        for current_strategy in strategies_generator: #deviation exploration for involved agents
            found_solution = pruning(model, agents, CTLformula, current_strategy)
            if found_solution:
                print("Solution found! It is not a Nash Equilibrium!")
                with open(result, 'a') as f:
                    f.write(f"Satisfiabilty: {str(found_solution)}\n")
                    f.write(f"Complexity Bound: {str(i)}\n")
                    f.write(f"Winning Strategy per agent: {str(current_strategy)}\n")
                    print(f"Winning Strategy per agent: {current_strategy}")
                    end_time = time.time()
                    elapsed_time = end_time - start_time
                    print(f"Elapsed time is {elapsed_time} seconds.")
                    with open(result, 'a') as f:
                        f.write(f"Execution time: {elapsed_time} seconds\n")
                return found_solution
        i += 1
    else:
        if not found_solution:
            print(f"Formula does not satisfy the given model, the game brings to a Nash Equilibrium for the selected agents")
            with open(result, 'a') as f:
                f.write(f"Satisfiabilty: {str(found_solution)}\n")
                f.write(f"Complexity Bound: {str(k)}\n")
                end_time = time.time()
                elapsed_time = end_time - start_time
                print(f"Elapsed time is {elapsed_time} seconds.")
                with open(result, 'a') as f:
                    f.write(f"Execution time: {elapsed_time} seconds\n")
                return found_solution


def process_data(model, formula, result):

    boolean = sureWin(model,formula,result)
    if boolean:
        print("Satisfiable formula")
    else:
        print("Unsatisfiable formula")




#Main function
if __name__ == "__main__":
    process = multiprocessing.Process(target=process_data(model, formulaLTL, result))
    process.start()
    process.join(timeout=7200)  # Set timeout for tests to 7200 seconds (2 hours)

    if process.is_alive():
        print("The execution is still going after 2 hours....Terminating....Time is up! No solution found!")
        process.terminate()
        process.join()