import multiprocessing
import time
from src.strategies import initialize, generate_guarded_action_pairs, generate_strategies, generate_deviations_for_agent
from src.pruning import pruning

model = 'C:\\Users\\utente\\Desktop\\Lavoro\\LTL\\Memoryless\\Testing\\MultiAgent.txt'
result = 'C:\\Users\\utente\\Desktop\\Lavoro\\LTL\\Memoryless\\Testing\\result.txt'
formulaLTL = 'C:\\Users\\utente\\Desktop\\Lavoro\\LTL\\Memoryless\\Testing\\formulaLTL1.txt'


def process_data(model, formula, result):
    """
    Funzione preliminare che:
    - Inizializza il modello e la formula (initialize())
    - Se l'utente ha inserito manualmente le strategie naturali, le usa e verifica (con isNotNash)
      se esiste una deviazione unilaterale vincente, altrimenti itera sui bound di complessità
      generando le strategie collettive e utilizzando existsNash.
    - Se viene trovata una deviazione (cioè, la strategia non è un Nash Equilibrium) o, al contrario,
      nessuna deviazione viene trovata (Nash Equilibrium), registra i dati e termina.
    """
    import time
    start_time = time.time()
    # Inizializza e raccoglie tutti i dati necessari
    k, agent_actions, actions_list, atomic_propositions, CTLformula, agents, cgs, nash_agents, natural_strategies = initialize(model, formula)
    found_solution = False

    # Se l'utente ha inserito manualmente le strategie naturali, verifichiamo con isNotNash
    if natural_strategies is not None:
        print("\nUtilizzo delle strategie naturali fornite manualmente dall'utente.")
        if isNotNash(cgs, list(range(1, nash_agents + 1)), CTLformula, natural_strategies, k, agent_actions, atomic_propositions):
            elapsed_time = time.time() - start_time
            print("Deviazione trovata: la strategia naturale NON è un Nash Equilibrium!")
            with open(result, 'a') as f:
                f.write("Satisfiability: False\n")
                f.write(f"Strategia naturale per agenti: {natural_strategies}\n")
                f.write(f"Execution time: {elapsed_time} seconds\n")
            return False
        else:
            elapsed_time = time.time() - start_time
            print("Nessuna deviazione trovata: la strategia naturale risulta essere un Nash Equilibrium!")
            with open(result, 'a') as f:
                f.write("Satisfiability: True\n")
                f.write(f"Strategia naturale per agenti: {natural_strategies}\n")
                f.write(f"Execution time: {elapsed_time} seconds\n")
            return True

    # Altrimenti, itera sui possibili bound di complessità da 1 a k
    for i in range(1, k + 1):
        cartesian_products = generate_guarded_action_pairs(i, agent_actions, actions_list, atomic_propositions)
        strategies_generator = generate_strategies(cartesian_products, i, agents, found_solution)

        # Per ogni strategia collettiva generata
        for current_strategy in strategies_generator:
            # existsNash viene usata per verificare se esiste almeno una deviazione vincente per qualche agente
            if existsNash(cgs, list(range(1, nash_agents + 1)), CTLformula, current_strategy, i, agent_actions, atomic_propositions):
                elapsed_time = time.time() - start_time
                print("Nash Equilibrium trovato!")
                with open(result, 'a') as f:
                    f.write("Satisfiability: True\n")
                    f.write(f"Complexity Bound: {i}\n")
                    f.write(f"Winning Strategy per agent: {current_strategy}\n")
                    f.write(f"Execution time: {elapsed_time} seconds\n")
                return True

    elapsed_time = time.time() - start_time
    print("The game doesn't lead to a Nash Equilibrium for the selected agents")
    with open(result, 'a') as f:
        f.write("Satisfiability: False\n")
        f.write(f"Complexity Bound: {k}\n")
        f.write(f"Execution time: {elapsed_time} seconds\n")
    return False


def isNotNash(model, agents, CTLformula, current_strategy, bound, agent_actions, atomic_propositions):
    """
    Data una strategia collettiva corrente, itera sugli agenti e verifica se per almeno uno di essi esiste
    una deviazione unilaterale che, sostituendo la strategia individuale corrente in current_strategy, porta
    a un outcome favorevole (verificato da pruning()).
    """
    for agent_index, agent in enumerate(agents):
        print(f"Agente {agent_index}: {agent}")
        print(f"Strategia corrente passata a pruning: {current_strategy}")
        if not pruning(model, agents, CTLformula, current_strategy):
            agent_key = f"actions_agent{agent}"
            agent_actions_for_agent = agent_actions.get(agent_key, [])
            print(f"Azioni disponibili per l'agente {agent}: {agent_actions_for_agent}")
            deviations = generate_deviations_for_agent(
                current_strategy[agent_index],
                bound,
                agent_actions_for_agent,
                atomic_propositions
            )
            for deviation in deviations:
                original_strategy = current_strategy[agent_index]
                current_strategy[agent_index] = deviation
                print(f"Strategia modificata per agente {agent}: {current_strategy}")
                if pruning(model, agents, CTLformula, current_strategy):
                    print(f"Deviazione trovata per l'agente {agent}: {deviation}")
                    return True
                current_strategy[agent_index] = original_strategy
    return False


def existsNash(cgs, agents, CTLformula, current_strategy, i, agent_actions, atomic_propositions):
    return not isNotNash(cgs, agents, CTLformula, current_strategy, i, agent_actions, atomic_propositions)



def NashDisequilibrium(model, formulaLTL, result):
    result = process_data(model, formulaLTL, result)




def winsSomeNash(cgs, agents, CTLformula, current_strategy, bound, agent_actions, atomic_propositions, target_agent):
    """
    Verifica se esiste un profilo strategico Nash in cui l'agente target raggiunge il proprio obiettivo.

    Secondo la descrizione a pagina 5:
      1. Si "indovina" un profilo strategico sAgt (current_strategy);
      2. Se il percorso risultante (path(sAgt)) soddisfa la formula di target_agent (Φ_target)
         e se il profilo strategico è un Nash Equilibrium (ossia, non esistono deviazioni vantaggiose per alcun agente),
         allora la funzione restituisce True.

    Parametri:
      - cgs: il modello (o struttura del gioco)
      - agents: lista degli agenti coinvolti
      - CTLformula: dizionario contenente la formula CTL per ciascun agente (unica formula, perchè formule identiche)
      - current_strategy: profilo strategico corrente (lista di strategie individuali)
      - bound: bound di complessità corrente
      - agent_actions: dizionario delle azioni disponibili per ciascun agente
      - atomic_propositions: lista delle atomic propositions usate per generare le condizioni
      - target_agent: l'agente per il quale verificare il raggiungimento dell'obiettivo

    Restituisce True se:
      - il percorso generato dal profilo strategico corrente soddisfa la formula di target_agent, e
      - il profilo strategico è un Nash Equilibrium (ossia, non esiste una deviazione unilaterale vantaggiosa per alcun agente);
    altrimenti False.
    """
    # Controlla se il percorso (outcome) soddisfa l'obiettivo del target_agent.
    if check_agent_win(cgs, target_agent, CTLformula, current_strategy) and not isNotNash(cgs, agents, CTLformula, current_strategy, bound, agent_actions, atomic_propositions):
        return False
    return True


 # Check if the agent loses in some Nash equilibrium
def check_agent_win(model, agent, CTLformula, current_strategy):
    """
    Funzione ausiliaria che verifica se il percorso derivato dal profilo strategico corrente
    soddisfa l'obiettivo (formula CTL) dell'agente specificato.

    Si assume che:
      - Potrei implementare CTLformula come un dizionario in cui CTLformula[agent] è la formula dell'agente, MA dato che intendo formule identiche non c'è bisogno
      - La funzione pruning(), se invocata passando come lista degli agenti solo [agent]
        e la formula per quell'agente, restituisce True se l'outcome
        soddisfa il goal dell'agente.
    """
    return pruning(model, [agent], CTLformula, current_strategy)


def LoseSomeNash(cgs, agents, CTLformula, current_strategy, bound, agent_actions, atomic_propositions, target_agent):

    if not check_agent_win(cgs, target_agent, CTLformula, current_strategy) and not isNotNash(cgs, agents, CTLformula, current_strategy, bound, agent_actions, atomic_propositions):
        return True
    return False


#Main function
if __name__ == "__main__":
    process = multiprocessing.Process(target=NashDisequilibrium(model, formulaLTL, result))
    process.start()
    process.join(timeout=7200)  # Set timeout for tests to 7200 seconds (2 hours)

    if process.is_alive():
        print("The execution is still going after 2 hours....Terminating....Time is up! No solution found!")
        process.terminate()
        process.join()

