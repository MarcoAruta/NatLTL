from collections import defaultdict

from util.functions import *
from binarytree import Node
from util.ATLparser import do_parsingATL, verifyATL


# returns the states where the proposition holds
def get_states_prop_holdsATL(prop):
    states = set()
    prop_matrix = get_matrix_proposition()

    index = get_atom_index(prop)
    if index is None:
        return None
    for state, source in enumerate(prop_matrix):
        if source[int(index)] == 1:
            states.add(state)
    return states


# set of states (ex. s1, s2) as input and returns a set of indices to identify them
def convert_state_setATL(state_set):
    states = set()
    for elem in state_set:
        position = get_index_by_state_name(elem)
        states.add(int(position))
    return states


# converts a string into a set
def string_to_setATL(string):
    if string == 'set()':
        return set()
    set_list = string.strip("{}").split(", ")
    new_string = "{" + ", ".join(set_list) + "}"
    return eval(new_string)


#  function that builds a formula tree, used by the model checker
def build_treeATL(tpl):
    if isinstance(tpl, tuple):
        root = Node(tpl[0])
        if len(tpl) > 1:
            left_child = build_treeATL(tpl[1])
            if left_child is None:
                return None
            root.left = left_child
            if len(tpl) > 2:
                right_child = build_treeATL(tpl[2])
                if right_child is None:
                    return None
                root.right = right_child
    else:
        states = set()
        states_proposition = get_states_prop_holdsATL(str(tpl))
        if states_proposition is None:
            return None
        else:
            for element in states_proposition:
                states.add(get_state_name_by_index(element))
            root = Node(str(states))
    return root


# It returns the states from which the coalition has a strategy to enforce the next state to lie in state_set.
# function used by the model checker.

def pre(coalition, state_set):
    agents = get_agents_from_coalition(coalition)
    graph = get_graph()
    state_set = convert_state_setATL(state_set)  # returns a set of indexes
    pre_states = set()
    dict_state_action = dict()  # dictionary state-action

    for i, source in enumerate(graph):  # take states that have at least one transition to one of the states in the set
        for j in state_set:
            if graph[i][j] != 0:
                coordinates = str(i) + "," + str(j)
                dict_state_action.update({coordinates: build_list(graph[i][j])})
    # iterate over these states and check that my move is not present in any other state
    for key, value in dict_state_action.items():
        other_actions_in_row = dict()  # dictionary containing other moves of the row (excluding those saved in dict_state_action).
        all_actions_in_row = set()  # all elements in the row
        i = int(key.split(',')[0])
        j = int(key.split(',')[1])
        for index, element in enumerate(graph[i]):
            if element != 0:
                coordinates = str(i) + "," + str(index)
                all_actions_in_row.update(build_list(graph[i][index]))
                if not state_set.__contains__(
                        index):  ## old = if (index != j) wrong because it would add to the "other_actions_in_row" also "positive" actions that would lead to another target state
                    other_actions_in_row.update({coordinates: build_list(graph[i][index])})
                    # check if there is a loop -> if yes, it is a pre
        for y in value:
            if '*' in y:
                pre_states.add(str(i))
                break

        column = -1
        other_act = set()

        for action in value:
            move = get_coalition_action(set([action]), agents)
            # checks whether a move is present in the others
            check_passed = True
            for k, v in other_actions_in_row.items():

                for act in v:
                    other_act = other_act.union(get_coalition_action(set([act]), agents))
                if move.intersection(other_act):  # they have something in common
                    check_passed = False
                    # print("did not passed: " + str(i) + " " + str(j) + " " + action)
            if check_passed == True:
                pre_states.add(get_state_name_by_index(i))

    return pre_states


# function that solves the formula tree. The result is the model checking result.
# It solves every node depending on the operator.
def solve_treeATL(node):
    if node.left is not None:
        print(f"node left: {node.left}")
        print(type(node.left))
        solve_treeATL(node.left)
    if node.right is not None:
        print(f"node right: {node.right}")
        solve_treeATL(node.right)

    if node.right is None:  # UNARY OPERATORS: not, globally, next, eventually
        if verifyATL('NOT', node.value):  # e.g. ¬φ
            states = string_to_setATL(node.left.value)
            all_states = set(get_states())
            ris = all_states - states
            node.value = str(ris)

        elif verifyATL('COALITION', node.value) and verifyATL('GLOBALLY', node.value):  # e.g. <1>Gφ
            coalition = node.value[1:-2]
            states = string_to_setATL(node.left.value)
            p = set(get_states())
            t = states
            while p - t:  # p not in t
                p = t
                t = pre(coalition, p) & states
            node.value = str(p)

        elif verifyATL('COALITION', node.value) and verifyATL('NEXT', node.value):  # e.g. <1>Xφ
            coalition = node.value[1:-2]
            states = string_to_setATL(node.left.value)
            ris = pre(coalition, states)
            print(f"risultato pre: {ris}")
            node.value = str(ris)

        elif verifyATL('COALITION', node.value) and verifyATL('EVENTUALLY', node.value):  # e.g. <1>Fφ
            # trueUϕ.
            coalition = node.value[1:-2]
            states = string_to_setATL(node.left.value)
            p = set()
            t = states
            while t - p:  # t not in p
                p.update(t)
                t = pre(coalition, p)
            node.value = str(p)

    if node.left is not None and node.right is not None:  # BINARY OPERATORS: or, and, until, implies
        if verifyATL('OR', node.value):  # e.g. φ || θ
            states1 = string_to_setATL(node.left.value)
            states2 = string_to_setATL(node.right.value)
            ris = states1.union(states2)
            node.value = str(ris)

        elif verifyATL('COALITION', node.value) and verifyATL('UNTIL', node.value):  # e.g. <1>φUθ
            coalition = node.value[1:-2]
            states1 = string_to_setATL(node.left.value)
            states2 = string_to_setATL(node.right.value)
            p = set()
            t = states2
            while t - p:  # t not in p
                p.update(t)
                t = pre(coalition, p) & states1
            node.value = str(p)

        elif verifyATL('AND', node.value):  # e.g. φ && θ
            states1 = string_to_setATL(node.left.value)
            states2 = string_to_setATL(node.right.value)
            ris = states1.intersection(states2)
            node.value = str(ris)

        elif verifyATL('IMPLIES', node.value):  # e.g. φ -> θ
            # p -> q ≡ ¬p ∨ q
            states1 = string_to_setATL(node.left.value)
            states2 = string_to_setATL(node.right.value)
            not_states1 = set(get_states()).difference(states1)
            ris = not_states1.union(states2)
            node.value = str(ris)


# returns whether the result of model checking is true or false in the initial state
def verify_initial_stateATL(initial_state, string):
    if initial_state in string:
        return True
    return False


# does the parsing of the model, the formula, builds a tree and then it returns the result of model checking
# function called by front_end_CS
def model_checkingATL(formula, filename):
    if not formula.strip():
        result = {'res': 'Error: formula not entered', 'initial_state': ''}
        return result

    # model parsing
    read_file(filename)

    # formula parsing
    res_parsing = do_parsingATL(formula, get_number_of_agents())
    print(f"res parsing: {res_parsing}")
    if res_parsing is None:
        result = {'res': "Syntax Error", 'initial_state': ''}
        return result
    root = build_treeATL(res_parsing)
    if root is None:
        result = {'res': "Syntax Error: the atom does not exist", 'initial_state': ''}
        return result
    # model checking
    solve_treeATL(root)

    # solution
    initial_state = get_initial_state()
    bool_res = verify_initial_stateATL(initial_state, root.value)
    result = {'res': 'Result: ' + str(root.value),
              'initial_state': 'Initial state ' + str(initial_state) + ": " + str(bool_res)}
    return result